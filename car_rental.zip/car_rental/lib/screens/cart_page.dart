import 'package:flutter/material.dart';

class CartPage extends StatelessWidget {
   CartPage({super.key});

  final List<Map<String, dynamic>> cartItems = [
    {
      'image': 'assets/images/car1.jpg',
      'name': 'Car Model 1',
      'price': '\$20,000',
    },
    {
      'image': 'assets/images/car2.jpg',
      'name': 'Car Model 2',
      'price': '\$25,000',
    },
    {
      'image': 'assets/images/car3.jpg',
      'name': 'Car Model 3',
      'price': '\$30,000',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Cart'),
        backgroundColor: Colors.red,
      ),
      body: ListView.builder(
        itemCount: cartItems.length,
        itemBuilder: (context, index) {
          final item = cartItems[index];
          return Card(
            margin: const EdgeInsets.all(8.0),
            child: ListTile(
              leading: Image.asset(item['image'], width: 100, fit: BoxFit.cover),
              title: Text(item['name']),
              subtitle: Text(item['price']),
              trailing: IconButton(
                icon: const Icon(Icons.remove_circle_outline),
                onPressed: () {
                },
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ElevatedButton(
          onPressed: () {
            //  checkout
          },
          child: const Text('Checkout'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red, // Button color
            padding: const EdgeInsets.symmetric(vertical: 15),
            textStyle: const TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }
}
